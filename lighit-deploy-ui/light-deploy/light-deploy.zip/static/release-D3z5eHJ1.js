import{s as r}from"./index-B-GP22XE.js";function t(e){return r({url:"/release/page",method:"get",params:e})}function a(e){return r({url:"/release/list",method:"get",params:e})}export{a as l,t as p};
